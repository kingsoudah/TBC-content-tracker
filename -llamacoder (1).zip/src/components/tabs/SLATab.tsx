import { ProductData } from "../../types";
import { getSLADetails } from "../../utils/dataUtils";
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, BarChart, Bar, XAxis, YAxis, CartesianGrid } from "recharts";

interface SLATabProps {
  data: ProductData[];
}

export function SLATab({ data }: SLATabProps) {
  const slaDetails = getSLADetails(data);
  
  const compliantSKUs = slaDetails.filter(item => item.isSLACompliant);
  const nonCompliantSKUs = slaDetails.filter(item => !item.isSLACompliant);
  
  const missingImages = slaDetails.filter(item => !item.hasImages);
  const missingContent = slaDetails.filter(item => !item.hasContent);

  const pieData = [
    { name: "SLA Compliant", value: compliantSKUs.length, color: "#10b981" },
    { name: "Non-Compliant", value: nonCompliantSKUs.length, color: "#ef4444" },
  ];

  const slaPercentage = data.length > 0 ? ((compliantSKUs.length / data.length) * 100).toFixed(1) : "0";

  const imageCountDistribution = [
    { name: "0 images", count: slaDetails.filter(item => item.imageCount === 0).length },
    { name: "1 image", count: slaDetails.filter(item => item.imageCount === 1).length },
    { name: "2 images", count: slaDetails.filter(item => item.imageCount === 2).length },
    { name: "3+ images", count: slaDetails.filter(item => item.imageCount >= 3).length },
  ];

  return (
    <div className="space-y-8">
      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-6">
          <p className="text-sm text-emerald-700 font-medium mb-1">SLA Compliant</p>
          <p className="text-3xl font-bold text-emerald-800">{compliantSKUs.length}</p>
          <p className="text-xs text-emerald-600 mt-1">2+ images & has content</p>
        </div>

        <div className="bg-red-50 border border-red-200 rounded-xl p-6">
          <p className="text-sm text-red-700 font-medium mb-1">Non-Compliant</p>
          <p className="text-3xl font-bold text-red-800">{nonCompliantSKUs.length}</p>
          <p className="text-xs text-red-600 mt-1">Missing requirements</p>
        </div>

        <div className="bg-amber-50 border border-amber-200 rounded-xl p-6">
          <p className="text-sm text-amber-700 font-medium mb-1">Missing Images</p>
          <p className="text-3xl font-bold text-amber-800">{missingImages.length}</p>
          <p className="text-xs text-amber-600 mt-1">Less than 2 images</p>
        </div>

        <div className="bg-sky-50 border border-sky-200 rounded-xl p-6">
          <p className="text-sm text-sky-700 font-medium mb-1">Missing Content</p>
          <p className="text-3xl font-bold text-sky-800">{missingContent.length}</p>
          <p className="text-xs text-sky-600 mt-1">Empty content field</p>
        </div>
      </div>

      {/* Main Metric */}
      <div className="bg-white rounded-xl border border-slate-200 p-8">
        <div className="text-center mb-8">
          <h3 className="text-lg font-semibold text-slate-800 mb-2">SLA Adherence Rate</h3>
          <p className="text-6xl font-bold text-emerald-600">{slaPercentage}%</p>
          <p className="text-slate-500 mt-2">
            {compliantSKUs.length} out of {data.length} SKUs meet SLA requirements
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="h-72">
            <h4 className="text-sm font-medium text-slate-600 mb-4 text-center">Compliance Distribution</h4>
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={pieData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={90}
                  paddingAngle={3}
                  dataKey="value"
                  label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                >
                  {pieData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </div>

          <div className="h-72">
            <h4 className="text-sm font-medium text-slate-600 mb-4 text-center">Image Count Distribution</h4>
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={imageCountDistribution}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                <XAxis dataKey="name" tick={{ fill: "#64748b", fontSize: 11 }} />
                <YAxis tick={{ fill: "#64748b", fontSize: 12 }} />
                <Tooltip />
                <Bar dataKey="count" fill="#6366f1" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Non-Compliant SKUs Table */}
      <div className="bg-white rounded-xl border border-slate-200 overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-200">
          <h3 className="text-lg font-semibold text-slate-800">Non-Compliant SKUs</h3>
          <p className="text-sm text-slate-500">SKUs that need attention</p>
        </div>
        <div className="overflow-x-auto max-h-96">
          <table className="w-full">
            <thead className="bg-slate-50 sticky top-0">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase">SKU</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase">Title</th>
                <th className="px-6 py-3 text-center text-xs font-medium text-slate-500 uppercase">Images</th>
                <th className="px-6 py-3 text-center text-xs font-medium text-slate-500 uppercase">Content</th>
                <th className="px-6 py-3 text-center text-xs font-medium text-slate-500 uppercase">Stock</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200">
              {nonCompliantSKUs.slice(0, 50).map((item, index) => (
                <tr key={index} className="hover:bg-slate-50">
                  <td className="px-6 py-4 text-sm font-medium text-slate-900">{item.sku}</td>
                  <td className="px-6 py-4 text-sm text-slate-600 max-w-xs truncate">{item.title}</td>
                  <td className="px-6 py-4 text-center">
                    <span className={`inline-flex px-2 py-1 text-xs font-medium rounded-full ${
                      item.hasImages ? 'bg-emerald-100 text-emerald-700' : 'bg-red-100 text-red-700'
                    }`}>
                      {item.imageCount}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-center">
                    <span className={`inline-flex px-2 py-1 text-xs font-medium rounded-full ${
                      item.hasContent ? 'bg-emerald-100 text-emerald-700' : 'bg-red-100 text-red-700'
                    }`}>
                      {item.hasContent ? 'Yes' : 'No'}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-sm text-center font-medium text-slate-900">{item.stock}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}